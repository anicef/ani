package animal;

public class Animal {
	private int animal_id; // ���� ID
	private String animal_name; // ���� �̸�
	private String animal_sex; // ���� ����
	private int animal_age; // ���� ����
	private String animal_local; // ���� ����
	private String animal_ox; // ���� �߼�ȭ ����
	private String animal_health; // ���� �ǰ� ����
	
	public int getAnimal_id() {
		return animal_id;
	}
	public void setAnimal_id(int animal_id) {
		this.animal_id = animal_id;
	}
	public String getAnimal_name() {
		return animal_name;
	}
	public void setAnimal_name(String animal_name) {
		this.animal_name = animal_name;
	}
	public String getAnimal_sex() {
		return animal_sex;
	}
	public void setAnimal_sex(String animal_sex) {
		this.animal_sex = animal_sex;
	}
	public int getAnimal_age() {
		return animal_age;
	}
	public void setAnimal_age(int animal_age) {
		this.animal_age = animal_age;
	}
	public String getAnimal_local() {
		return animal_local;
	}
	public void setAnimal_local(String animal_local) {
		this.animal_local = animal_local;
	}
	public String getAnimal_ox() {
		return animal_ox;
	}
	public void setAnimal_ox(String animal_ox) {
		this.animal_ox = animal_ox;
	}
	public String getAnimal_health() {
		return animal_health;
	}
	public void setAnimal_health(String animal_health) {
		this.animal_health = animal_health;
	}
}