package animal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AnimalDAO {
	// DB���� ��ü�� ����
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;

	// ������
	public AnimalDAO() {
		// DB����
		try {
			String dbURL = "jdbc:mysql://localhost:3306/anicef?useSSL=false";
			String dbID = "root";
			String dbPassword = "1234";
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
			// System.out.println("�����");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
